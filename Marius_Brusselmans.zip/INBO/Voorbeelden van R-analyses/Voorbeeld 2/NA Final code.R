########################################################################
#Marius Brusselmans
#Network Analysis assignment Code
#31 March 2022
#####################################################################
setwd("C:/Users/mbrus/Desktop/Network Analysis/Full Analysis")
dev.off()
rm(list=ls())
detach(package:igraph)
library(sna)
library(reshape2)
library(ggplot2)
library(tidyverse)
library(gapminder)
library(data.table)

###############################################################
#Data Setup
###############################################################
affective_w1 <- as.matrix(read.csv("3300_affective_w1.csv",header=TRUE, row.names=1, sep=","))
affective_w2 <- as.matrix(read.csv("3300_affective_w2.csv",header=TRUE, row.names=1, sep=","))
sex <- as.matrix(read.csv("3300_sex.csv",header=TRUE, row.names=1, sep=","))
drink <- as.matrix(read.csv("3300_drink.csv",header=TRUE, row.names=1, sep=","))
#recode friendship networks
friend1 <- affective_w1
friend1[friend1 != 2 & !is.na(friend1)] <- 0 
friend1[friend1 == 2] <- 1
friend2 <- affective_w2
friend2[friend2 != 2 & !is.na(friend2)] <- 0 
friend2[friend2 == 2] <- 1
#recode boy=0, girl=1
sex <- sex-1
#Student identifiers
id<-substr(rownames(friend1), 3, 4)

###############################################################
#Basic exploration and plotting
###############################################################
#Amount of students:
class_size <- ncol(affective_w1)
#Boys/girls
gender_comp <- table(sex)
gender_comp
#Missingness
miss1 <- sum(is.na(friend1)) - 34
miss1 <- miss1 / ( nrow(friend1) * (ncol(friend1) - 1) )
miss1 #5 students are missing, no intermittent
miss2 <- sum(is.na(friend2)) - 34
miss2 <- miss2 / ( nrow(friend2) * (ncol(friend2) - 1) )
miss2 #Only 1 student is missing, intermittent as well
#Drinking
dev.off()
drinkchange <- data.frame(drink,id,sex)
d<-drink
d[d[,1]==d[,2],1:2] <- NA
pijl <- data.frame(c(d[,1],d[,2]),rep(id,2))
colnames(pijl)<-c("drnk","id")
ggplot() +
  geom_bar(data=drinkchange,aes(x=id, y=drinking.w1), stat="identity", position ="identity", alpha=.3, fill='red', color='black') +
  geom_bar(data=drinkchange,aes(x=id, y=drinking.w2), stat="identity", position="identity", alpha=.2, fill='blue', color='black') +
  geom_path(data=pijl,aes(x=id,y = drnk, group = id), 
            arrow = arrow(type="open"),size=1.5) +
  ylab("drinking level") +
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1,colour = sex+1))


#Density
dens1 <- gden(friend1)
dens2 <- gden(friend2)
dens2/dens1 #Network becomes less dense
#Plotting the network
load("plot_coords.RData") #friend_plot1 <- gplot(friend1)
size <- replace(sex+2, which(sex %in% c(0)), 4)
col <- drink %>% 
  replace(which(drink %in% c(1)), "lightskyblue1")  %>% 
  replace(which(drink %in% c(2)), "lightskyblue3")  %>% 
  replace(which(drink %in% c(3)), "lightskyblue4")  %>% 
  replace(which(drink %in% c(4)), "black")
dev.off()
par(mfrow=c(1,2))
gplot(friend1, coord=friend_plot1, vertex.col=col[,1], jitter=T, vertex.sides = size, vertex.cex=2)
title(main = "Wave 1")
gplot(friend2, coord=friend_plot1, vertex.col=col[,2], jitter=T, vertex.sides = size, vertex.cex=2)
title(main = "Wave 2")
dev.off()
plot.new()
legend(.5,1, col=c("lightskyblue1","lightskyblue3","lightskyblue4","black"),cex=1, title="drink", legend=c("1", "2","3","4"), pch=19)
legend(.1,1, col=c("black","black"),cex=1, title="sex", legend=c("girls", "boys"), pch=c(2,0))
#connected
library(igraph)
graph1 <- graph.adjacency(friend1)
is.connected(graph1) #No islands



###############################################################
#PART 2
###############################################################
#Random network
sim1 <- rgraph(34,100,dens1)
sim2 <- rgraph(34,100,dens2)
#Reciprocity
rec1 <- grecip(friend1, measure="dyadic.nonnull")#only 1/5 reciprocated, see Appendix I for bias check 
rec2 <- grecip(friend2, measure="dyadic.nonnull")#
simrec1 <- grecip(sim1, measure="dyadic.nonnull")
simrec2 <- grecip(sim2, measure="dyadic.nonnull")
simrec <- data.frame(c(simrec1,simrec2),c(rep("1",100),rep("2",100)))
colnames(simrec)<- c("reciprocity","wave")
realrec <- data.frame(c(rec1,rec2),c("1","2"))
colnames(realrec)<- c("reciprocity","wave")
ggplot() +
  geom_violin(data=simrec, aes(x=wave, y=reciprocity)) + 
  geom_dotplot(data=realrec, aes(x=wave,y=reciprocity),position=position_dodge(1),binaxis='y', stackdir='center',stackratio=1.5, dotsize=1.2) +
  ggtitle("Simulated and real reciprocity")
#Degrees
detach(package:igraph)
library(sna)
in1 <- degree(friend1, cmode="indegree") # indegrees
out1 <- degree(friend1, cmode="outdegree") # outdegrees
in2 <- degree(friend2, cmode="indegree") # indegrees
out2 <- degree(friend2, cmode="outdegree") # outdegrees
data <- data.frame(c(in1,in2),c(out1,out2), rep(id,2), c(rep(1,34),rep(2,34)))
colnames(data) <- c("ind", "outd", "id","time")
data$time <- factor(data$time)
data <- data[order(data$id),]  %>%  
  mutate(paired = rep(1:(n()/2),each=2),
         id=factor(id))
ggplot(data=data) +
  geom_point(aes(x = ind, y = outd),size = 1) + #I've made it bigger so you can see it better!
  geom_path(aes(x = ind, y = outd, group = id, color=id), 
            arrow = arrow(length = unit(0.55, "cm"))) +
  theme(legend.position = "none") +
  geom_abline(slope=1,intercept=0) +
  ggtitle("In and out-degree evolution between wave 1 and 2")
indeg <- data.frame(in1,in2,id)
outdeg <- data.frame(out1,out2,id)
ggplot(data=indeg, aes(x=id)) +
  geom_bar(aes(y=in1), stat="identity", position ="identity", alpha=.3, fill='red', color='black') +
  geom_bar(aes(y=in2), stat="identity", position="identity", alpha=.2, fill='blue', color='black') 
ggplot(data=outdeg, aes(x=id)) +
  geom_bar(aes(y=out1), stat="identity", position ="identity", alpha=.3, fill='red', color='black') +
  geom_bar(aes(y=out2), stat="identity", position="identity", alpha=.2, fill='blue', color='black')


#Dyads and Triads
dyad1 <- dyad.census(friend1)
dyad2 <- dyad.census(friend2)
triad1 <- triad.census(friend1)
triad2 <- triad.census(friend2)
simdyad1 <- dyad.census(sim1)
simdyad2 <- dyad.census(sim2)
simtriad1 <- triad.census(sim1)
simtriad2 <- triad.census(sim2)
longdyad1 <- melt(simdyad1, id.vars = c("Mut","Asym","Null"), variable.name = "ehm")
longdyad2 <- melt(simdyad2, id.vars = c("Mut","Asym","Null"), variable.name = "ehm")
simdyad<-cbind(rbind(longdyad1,longdyad2)[,-1],c(rep("t1",300),rep("t2",300)))
colnames(simdyad) <- c("type","value","time")
realdyad <- data.frame(as.numeric(cbind(c(dyad1,dyad2))),rep(c("Mut","Asym","Null"),2),c(rep("t1",3),rep("t2",3)))
colnames(realdyad) <- c("value","type","time")
ggplot() +
  geom_violin(data=simdyad, aes(x=type, y=value, fill=time)) + 
  geom_dotplot(data=realdyad, aes(x=type,y=value,fill=time),position=position_dodge(1),binaxis='y', stackdir='center',stackratio=1.5, dotsize=1.2)
#-> helps to explain reciprocity
longtriad1 <- melt(simtriad1, id.vars = colnames(simtriad1), variable.name = "ehm")
longtriad2 <- melt(simtriad2, id.vars = colnames(simtriad2), variable.name = "ehm")
simtriad<-cbind(rbind(longtriad1,longtriad2)[,-1],c(rep("t1",1600),rep("t2",1600)))
colnames(simtriad) <- c("type","value","time")
realtriad <- data.frame(as.numeric(cbind(c(triad1,triad2))),rep(colnames(simtriad1),2),c(rep("t1",16),rep("t2",16)))
colnames(realtriad) <- c("value","type","time")
simtriadA <- simtriad[simtriad$type %in% colnames(simtriad1)[1:8],]
realtriadA <- realtriad[realtriad$type %in% colnames(simtriad1)[1:8],]
simtriadB <- simtriad[simtriad$type %in% colnames(simtriad1)[9:16],]
realtriadB <- realtriad[realtriad$type %in% colnames(simtriad1)[9:16],]
ggplot() +
  geom_violin(data=simtriadA, aes(x=type, y=value, fill=time)) + 
  geom_dotplot(data=realtriadA, aes(x=type,y=value,fill=time),position=position_dodge(1),binaxis='y', stackdir='center',stackratio=1.5, dotsize=1.2)
ggplot() +
  geom_violin(data=simtriadB, aes(x=type, y=value, fill=time)) + 
  geom_dotplot(data=realtriadB, aes(x=type,y=value,fill=time),position=position_dodge(1),binaxis='y', stackdir='center',stackratio=1.5, dotsize=1.2)

#Centrality? 
#Degree centrality can just be answered via the bar charts
deg1 <- degree(friend1)
deg2 <- degree(friend2)
#closeness captures the tendency to be closest to everyone
close1 <- closeness(friend1)
close2 <- closeness(friend2)
center <- data.frame(in1, in2, close1, close2)
dev.off()
a<-ggplot(data=center) +
  geom_point(aes(x=in1, y=close1, col='wave 1')) +
  geom_point(aes(x=in2, y=close2, col='wave 2')) +
  ggtitle("indegree") + 
  ylab("closeness") +
  xlab("indegree") 
b<-ggplot(data=center) +
  geom_point(aes(x=out1, y=close1, col='wave 1')) +
  geom_point(aes(x=out2, y=close2, col='wave 2')) +
  ggtitle("outdegree") + 
  ylab("closeness") +
  xlab("outdegree")
library(ggpubr)
ggarrange(a,b + rremove("x.text"),
          ncol = 1, nrow = 2)
deltaclose<-close2-close1
gain <- ifelse(deltaclose > 0, "green", "red")
gplot(friend2, coord=friend_plot1, vertex.col=gain, jitter=T, vertex.sides = size, vertex.cex=2)
which(deltaclose > 0)
delta.in <- in2-in1
delta.out <- out2-out1
mean(delta.in[which(deltaclose > 0)])
mean(delta.in[which(deltaclose < 0)]) #we know the network as a whole
#becomes less dense, and theres not much difference in deltaindegree between those
#who gained and those who lost centrality.
mean(delta.out[which(deltaclose > 0)])
mean(delta.out[which(deltaclose < 0)])
#However, those who gain in closeness also increased their outdegree whereas
#those who lost in closeness tend to drop their outdegree.
#Maybe we can compare this to the simulated networks.
closedegree <- data.frame(c(1:400),rep(c("in","in","out","out"),100),rep(c("increase","decrease"),200))
realdegree <- data.frame(c("in","in","out","out"),
                         rep(c("increase","decrease"),2),  
                         c(mean(delta.in[which(deltaclose > 0)]),
                           mean(delta.in[which(deltaclose < 0)]),
                           mean(delta.out[which(deltaclose > 0)]),
                           mean(delta.out[which(deltaclose < 0)])
                         )
)
colnames(closedegree) <- c("difference","type","closeness")
colnames(realdegree) <- c("type","closeness","difference")

for (i in 1:100){
  a <- sim1[i,,]
  b <- sim2[i,,]
  dclose<-closeness(b)-closeness(a)
  din <- degree(b,cmode = "indegree")-degree(a,cmode = "indegree")
  dout <- degree(b,cmode = "outdegree")-degree(a,cmode = "outdegree")
  closedegree$difference[4*(i-1)+1]<-mean(din[which(dclose > 0)])
  closedegree$difference[4*(i-1)+2]<-mean(din[which(dclose < 0)])
  closedegree$difference[4*(i-1)+3]<-mean(dout[which(dclose > 0)])
  closedegree$difference[4*(i-1)+4]<-(dout[which(dclose < 0)])
}
ggplot() +
  geom_violin(data=closedegree, aes(x=closeness, y=difference, fill=type)) +
  geom_dotplot(data=realdegree, aes(x=closeness,y=difference,fill=type),position=position_dodge(1),binaxis='y', stackdir='center',stackratio=1.5, dotsize=1.2)


###############################################################
#PART 3
###############################################################
#Relative densities
detach(package:igraph)
library(sna)
sex.select <- matrix(NA, 4, 2)
rownames(sex.select) <- c("g->g", "g->b", "b->b", "b->g")
colnames(sex.select) <- c("time 1", "time 2")
gg.1 <- friend1[sex==1, sex==1]
gb.1 <- friend1[sex==1, sex==0]
bb.1 <- friend1[sex==0, sex==0]
bg.1 <- friend1[sex==0, sex==1]
gg.2 <- friend2[sex==1, sex==1]
gb.2 <- friend2[sex==1, sex==0]
bb.2 <- friend2[sex==0, sex==0]
bg.2 <- friend2[sex==0, sex==1]
sex.select[1,1] <- gden(gg.1, diag=FALSE)
sex.select[2,1] <- gden(gb.1, diag=TRUE)
sex.select[3,1] <- gden(bb.1, diag=FALSE)
sex.select[4,1] <- gden(bg.1, diag=TRUE)
sex.select[1,2] <- gden(gg.2, diag=FALSE)
sex.select[2,2] <- gden(gb.2, diag=FALSE)
sex.select[3,2] <- gden(bb.2, diag=FALSE)
sex.select[4,2] <- gden(bg.2, diag=FALSE)
sex.select
sex.select.norm <- cbind(sex.select[,1] / gden(friend1),sex.select[,2] / gden(friend2) )
sex.select.norm 
#assortativity coefficient
detach(package:sna)
library(igraph)
graph1 <- graph.adjacency(friend1)
graph2 <- graph.adjacency(friend2)
#Drink has missing values. So for the ones missing in w1 we give them their w2 value
#And the one whose missing both times I will give the gender mode (male)
drink2<-drink
drink2[is.na(drink2[,1]),1]<-drink2[is.na(drink2[,1]),2]
table(drink[sex==0,1])
table(drink[sex==0,2])
drink2[is.na(drink2[,1]),1]<-3
drink2[is.na(drink2[,2]),2]<-3
assortativity_nominal(graph1, sex+1)
assortativity_nominal(graph2, sex+1)
assortativity_nominal(graph1, drink2[,1])
assortativity_nominal(graph2, drink2[,2])
detach(package:igraph)
library(igraph)
simass <- data.frame(c(1:400),rep(c("sex","sex","drink","drink"),100),rep(c("t1","t2"),200))
realass <- data.frame(c("sex","sex","drink","drink"),
                      rep(c("t1","t2"),2),  
                      c(assortativity_nominal(graph1, sex+1),
                        assortativity_nominal(graph2, sex+1),
                        assortativity_nominal(graph1, drink2[,1]),
                        assortativity_nominal(graph2, drink2[,2])
                      )
)
colnames(simass) <- c("assortativity","variable","time")
colnames(realass) <- c("variable","time","assortativity")

for (i in 1:100){
  a <- sim1[i,,]
  b <- sim2[i,,]
  grapha <- graph.adjacency(a)
  graphb <- graph.adjacency(b)
  simass$assortativity[4*(i-1)+1]<-assortativity_nominal(grapha, sex+1)
  simass$assortativity[4*(i-1)+2]<-assortativity_nominal(graphb, sex+1)
  simass$assortativity[4*(i-1)+3]<-assortativity_nominal(grapha, drink2[,1])
  simass$assortativity[4*(i-1)+4]<-assortativity_nominal(graphb, drink2[,2])
}
ggplot() +
  geom_violin(data=simass, aes(x=variable, y=assortativity, fill=time)) +
  geom_dotplot(data=realass, aes(x=variable,y=assortativity,fill=time),position=position_dodge(1),binaxis='y', stackdir='center',stackratio=1.5, dotsize=1.2) +
  ggtitle("assortativity coefficients")

#Jaccard Index
A <- sum((friend1 * friend2)==1, na.rm=TRUE) # #ties that exist in both networks
BplusC <- sum((friend1 + friend2)==1, na.rm=TRUE) # #ties that exist in only one network
(jaccard <- A/(A+BplusC))

#SAOM model
library(RSiena)
library(igraph)
graph1 <- graph.adjacency(friend1)
graph2 <- graph.adjacency(friend2)
graph12 <- graph.adjacency(friend1 + friend2)
myLayout <- layout.fruchterman.reingold(graph12)
# create dependent network variable
friend.dependent <- sienaDependent(array(c(friend1, friend2),dim=c(34, 34, 2)))
# create constant actor covariates
sex.co <- coCovar(as.integer(sex))
#Create variable actor covariate
#drink.co<- varCovar(drink)
#Doesn't work, so we use this (5.5 Rsiena manual)
drink.dep <- sienaDependent(drink, type="behavior")
#sienadata
mySienaData <- sienaDataCreate(friend.dependent,
                               sex.co,
                               drink.dep)
# print report to check
print01Report(mySienaData,
              modelname="mannheim_network_1")

# Specify sienna model

mySienaEffects <- getEffects(mySienaData)
# network effects
mySienaEffects <- includeEffects(mySienaEffects, transTrip, cycle3)
mySienaEffects <- includeEffects(mySienaEffects, inPop)
# homophily effects and ego alter control
mySienaEffects <- includeEffects(mySienaEffects, egoX, altX, sameX, interaction1="sex.co")
mySienaEffects <- includeEffects(mySienaEffects, egoX, altX, sameX,avXAltDist2, interaction1="drink.dep")
mySienaEffects <- includeEffects(mySienaEffects,avXAlt, interaction2 = "drink.dep", interaction1="friendship.dependent")
mySienaEffects # check parameters before estimation
  #For interpretation, especially of the smoking part: https://www.youtube.com/watch?v=HGnivBB89K4&t=4287s
#Siena algorithm
mySienaAlgorithm <- sienaAlgorithmCreate(projname="mannheim_network_1")
result <- siena07(mySienaAlgorithm,
                  data=mySienaData,
                  effects=mySienaEffects)
result