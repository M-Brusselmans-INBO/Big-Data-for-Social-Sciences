library(fpp2)
library(CADFtest)
library(forecast)
require(reshape2)
require(ggplot2)
library(vars)
library(urca)


##### Slide 2 #####

gas <- window(qgas, start=c(1970, 1), end=c(2010,2))
dgas <- diff(gas)
sdgas <- diff(diff(gas, lag=4))
ts.plot(gas,col="darkred", main="Australian gas production",ylab="Gas (PJ)",xlab="time (year)") #clear trend
grid (NULL,NULL, lty = 6, col = "gray")

##### Slide 3 #####

ts.plot(dgas,col="darkred", main="Australian gas production in Delta(1)",ylab="deltaGas (PJ)",xlab="time (year)") #Trend gone, but seems seasonal and cond hetero
grid (NULL,NULL, lty = 6, col = "gray") 
ts.plot(sdgas,col="darkred",main="Australian gas production in Delta(1)(4)",ylab="Gas (PJ)",xlab="time (year)") #seasonality seems gone, but cond hetero unclear
grid (NULL,NULL, lty = 6, col = "gray") 
CADFtest(gas, type="trend", criterion="BIC",max.lag.y=round(sqrt(length(dgas))))
acf(sdgas, main="Correlogram of Delta(1)(4) Gas")
pacf(sdgas, main="P-Correlogram of Delta(1)(4) Gas")

##### Slide 4 #####

M01.01<-arima(x=gas, order=c(0,1,1), seasonal=list(order=c(0,1,1), period=4), method="ML")
Box.test(M01.01$residuals, lag = 15, type = "Ljung-Box")
BIC(M01.01)
Box.test(M01.01$residuals^2, lag = 15, type = "Ljung-Box")
M10.01<-arima(x=gas, order=c(1,1,0), seasonal=list(order=c(0,1,1), period=4), method="ML")
Box.test(M10.01$residuals, lag = 15, type = "Ljung-Box")
BIC(M10.01)
M01.10<-arima(x=gas, order=c(0,1,1), seasonal=list(order=c(1,1,0), period=4), method="ML")
Box.test(M01.10$residuals, lag = 15, type = "Ljung-Box")
BIC(M01.10)
M10.10<-arima(x=gas, order=c(1,1,0), seasonal=list(order=c(1,1,0), period=4), method="ML")
Box.test(M10.10$residuals, lag = 15, type = "Ljung-Box")
BIC(M10.10)
M11.10<-arima(x=gas, order=c(1,1,1), seasonal=list(order=c(1,1,0), period=4), method="ML")
Box.test(M11.10$residuals, lag = 15, type = "Ljung-Box")
BIC(M11.10)
Box.test(M11.10$residuals^2, lag = 15, type = "Ljung-Box")
M11.01<-arima(x=gas, order=c(1,1,1), seasonal=list(order=c(0,1,1), period=4), method="ML")
Box.test(M11.01$residuals, lag = 15, type = "Ljung-Box")
BIC(M11.01)
Box.test(M11.01$residuals^2, lag = 15, type = "Ljung-Box")

##### Slide 5 #####

for11.10 <- predict(M11.10, n.ahead = 48)
for11.01 <- predict(M11.01, n.ahead = 48)
for01.01 <- predict(M01.01, n.ahead= 48)
a <- data.frame(merge(merge(for11.10$pred,for11.01$pred, all.x=TRUE,all.y=TRUE, sort=FALSE),for01.01$pred, all.x=TRUE,all.y=TRUE, sort=FALSE))
a$group <- c(rep("M11.10", times = 48),rep("M11.01", times = 48),rep("M01.01", times = 48))
a$lower <- data.frame(merge(merge(for11.10$pred-qnorm(0.975)*for11.10$se,for11.01$pred-qnorm(0.975)*for11.01$se, all.x=TRUE,all.y=TRUE, sort=FALSE),for01.01$pred-qnorm(0.975)*for01.01$se, all.x=TRUE,all.y=TRUE, sort=FALSE))
a$upper <- data.frame(merge(merge(for11.10$pred+qnorm(0.975)*for11.10$se,for11.01$pred+qnorm(0.975)*for11.01$se, all.x=TRUE,all.y=TRUE, sort=FALSE),for01.01$pred+qnorm(0.975)*for01.01$se, all.x=TRUE,all.y=TRUE, sort=FALSE))
a$time <- time(for11.10$pred)
h <- do.call(cbind, a)
colnames(h)<-c("PJ","model","lower","upper","time")
ggplot(h, aes(time, PJ, color = model, fill = model)) +
  geom_line(size = 1) +
  geom_ribbon(aes(ymin = lower, ymax = upper), alpha = .3, colour = NA) +
  ggtitle("Forecasts of different models")
#h=9
y<-gas
S=round(0.75*length(y))
h=12
error11.10<-c()
for (i in S:(length(y)-h)){
  mymodel.sub<-arima(x=gas[1:i], order=c(1,1,1), seasonal=list(order=c(1,1,0), period=4), method="ML")
  predict.h<-predict(mymodel.sub,n.ahead=h)$pred[h]
  print(predict.h)
  error11.10<-c(error11.10,y[i+h]-predict.h)
}
error11.01<-c()
for (i in S:(length(y)-h)){
  mymodel.sub<-arima(x=gas[1:i], order=c(1,1,1), seasonal=list(order=c(0,1,1), period=4), method="ML")
  predict.h<-predict(mymodel.sub,n.ahead=h)$pred[h]
  print(predict.h)
  error11.01<-c(error11.01,y[i+h]-predict.h)
}
error01.01<-c()
for (i in S:(length(y)-h)){
  mymodel.sub<-arima(x=gas[1:i], order=c(0,1,1), seasonal=list(order=c(0,1,1), period=4), method="ML")
  predict.h<-predict(mymodel.sub,n.ahead=h)$pred[h]
  print(predict.h)
  error01.01<-c(error01.01,y[i+h]-predict.h)
}
print(MAE11.10 <- mean(abs(error11.10)))
print(MAE11.01 <- mean(abs(error11.01)))
print(MAE01.01 <- mean(abs(error01.01)))
dm.test(error11.10,error11.01,h=h,power=1)
dm.test(error11.01,error01.01,h=h,power=1)
dm.test(error01.01,error11.10,h=h,power=1)

##### Slide 6 #####

M11.01

##### Slide 7 #####

elec <- window(qauselec, start=c(1970, 1), end=c(2010,2))
elecpeta <- elec*(1000000000/277777777.77778)
delec <- diff(elecpeta)
sdelec <- diff(diff(elecpeta, lag=4))
ts.plot(elecpeta,col="darkred", main="Australian gas production",ylab="Gas (PJ)",xlab="time (year)") #clear trend
grid (NULL,NULL, lty = 6, col = "gray")
ts.plot(delec,col="darkred", main="Australian gas production in Delta(1)",ylab="deltaGas (PJ)",xlab="time (year)") #Trend gone, but seems seasonal and cond hetero
grid (NULL,NULL, lty = 6, col = "gray") 
ts.plot(sdelec,col="darkred",main="Australian gas production in Delta(1)(4)",ylab="Gas (PJ)",xlab="time (year)") #seasonality seems gone, but cond hetero unclear
grid (NULL,NULL, lty = 6, col = "gray") 
CADFtest(elecpeta, type="trend", criterion="BIC",max.lag.y=round(sqrt(length(dgas))))
acf(sdgas, main="Correlogram of Delta(1)(4) Gas")
pacf(sdgas, main="P-Correlogram of Delta(1)(4) Gas")
ts.plot(gas, main="Electricity (red) and Gas (black) production",ylab="Petajoules",xlab="time (year)")
lines(elecpeta, col="red")
combo <- data.frame(gas, elecpeta)
names(combo)<-c("gas","elecpeta")
VARselect(combo,lag.max=10,type="const") #order 8
trace_test<-ca.jo(combo,type="trace",K=8,ecdet="const",spec="transitory")
summary(trace_test)
maxeigen_test<-ca.jo(combo,type="eigen",K=8,ecdet="const",spec="transitory")
summary(maxeigen_test)

##### Slide 8 #####

fit_vecm<-cajorls(trace_test,r=1)
fit_vecm
summary(fit_vecm$rlm)
anova(fit_vecm$rlm)
var<-vec2var(trace_test,r=1)
arch.test(var, lags.multi=15)

##### Slide 9 #####

fore<-predict(var,n.ahead=48)
fore$fcst$gas[,3]
b <- data.frame(c(fore$fcst$gas[,1],fore$fcst$elecpeta[,1]))
b$group <- c(rep("Gas", times = 48),rep("Elec", times = 48))
b$lower <- c(fore$fcst$gas[,2],fore$fcst$elecpeta[,2])
b$upper <- c(fore$fcst$gas[,3],fore$fcst$elecpeta[,3])
b$time <- time(for11.10$pred)
colnames(b)[1] <- "PJ"
ggplot(b, aes(time, PJ, color = group, fill = group)) +
  geom_line(size = 1) +
  geom_ribbon(aes(ymin = lower, ymax = upper), alpha = .3, colour = NA) +
  ggtitle("VAR forecast")

##### Slide 10 #####
irf_var<-irf(var,ortho=FALSE,boot=TRUE)
plot(irf_var)
