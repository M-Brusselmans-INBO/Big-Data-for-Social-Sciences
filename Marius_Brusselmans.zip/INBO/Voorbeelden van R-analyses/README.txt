In dit document vindt u drie voorbeelden van analyses die ik heb uigevoerd.

Elk voorbeeld bestaat uit een PDF of Powerpoint die de analyse beschrijft, alsook de bijhorende codes.
Het gaat hier enkel om analyses die ik alleen heb uitgevoerd, omdat ik niet zonder toestemming analyses
waar anderen aan hebben gewerkt wil delen. Dit is dus geen volledig overzicht van mijn competenties.

Voorbeeld 1 bespreekt een "time-series" analyse. Dit komt neer op een multivariate regressie 
maar met de moeilijkheid dat er correlatie is tussen opeenvolgende metingen aangezien er een
tijdgebonden relatie bestaat. Daarom gebruik ik techniken die deze autocorrelatie kunnen modelleren
zoals ARIMA (Autoregressive Integrated Moving Average) en VECM (Vector Error Correction Model). De
rapportering van deze analyse gebeurt in Powerpoint-vorm en is bijgevolg minder formeel/uitgebreid 
dan de andere voorbeelden.

Voorbeeld 2 bespreekt een "Network"-analyse. Hier worden de verbanden tussen verschillende actoren 
beschreven en gemodelleerd om zo op zoek te gaan naar relaties tussen eigenschappen zoals 
gender/alcoholgebruik en de tendens om vriendschappen te vormen. Het gebruikte model is hier een 
SAOM (Stochastic Actor-Oriënted Model)

Voorbeeld 3 bespreekt een simpel binomiaal model, wat dus een proportie modelleert. Dit is een Bayesiaanse
analyse. De nadruk van dit voorbeeld ligt vooral op Bayesiaanse modelselectie gebruik makende van 
Bayes factors.