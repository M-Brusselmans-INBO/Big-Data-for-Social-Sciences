################################################
################################################
################################################
#Marius Brusselmans
#Quantitative Psychology 2022
#Exam project code
################################################
################################################
#When running the code, please do so block per 
#block (as defined by these lines of hashtags)
################################################
################################################


################################################
#Setup
################################################
#Libraries and stuff
rm(list=ls())
setwd("C:/Users/mbrus/Desktop/Quantitative Psychology") #<- set working directory here
library("runjags")
library("rjags")
library(gtools)
library(coda)

#Data
#This data is a relic from when the model was different
#Still run it though, because the used data is derived from it.
mtg<-data.frame(matrix(ncol=8,nrow=0))
mtg <-              
  rbind(
    c(12,12,11,2,1),
    c(4,13,4,7,4),
    c(16,3,13,2,2),
    c(4,18,8,4,3),
    c(28,8,2,1,1),
    c(12,12,11,2,1),
    c(27,8,2,1,1),
    c(28,8,2,1,1),
    c(16,3,15,3,1),
    c(8,12,2,12,6),
    c(6,14,9,6,3),
    c(18,10,7,2,2),
    c(11,19,9,3,1),
    c(16,11,7,3,1),
    c(5,10,8,10,6),
    c(2,16,11,6,2),
    c(6,11,9,8,5),
    c(16,11,7,2,2),
    c(4,16,11,6,2), 
    c(6,17,7,5,3),
    c(20,13,4,3,2), 
    c(3,11,17,6,3),
    c(4,12,13,7,1), 
    c(1,8,14,10,4), 
    c(9,9,12,5,4), 
    c(5,14,5,6,3)
  )
landcount<-60-rowSums(mtg) #<- Thats our dataset

#Preparing the shape parameters-arrays
a <- rbind(c(1,1,1),c(1,1,1),c(1,1,1))
b <- rbind(c(1,1,1),c(1,1,1),c(1,1,1))

################################################
# Determining the shape parameters of Model 1
################################################

#Data from modern-day tournaments
modern <- c(22,25,25,25,22,24,26,26,26,23,24,22,26,22)

#Running a simple beta-binomial model
input <- list(
  y=modern, #outcome
  N=length(modern),
  n=60 #number of attempts per binomial trial
)
PARAM <- c("p") 
runjags.options(method = "rjags")
set.seed(1971215)
model1 <- run.jags(model = "priormodel.txt",
                   monitor = PARAM,
                   data = input,
                   burnin = 1000, sample = 10000, thin = 1,
                   n.chains = 1)
model1_sum<-summary(model1)
model1_sum
model1_mcmc <- combine.mcmc(model1)
#mean and variance
m <- mean(model1_mcmc)
v <- var(model1_mcmc)
#recalculated to beta parameters
a[1,1] <- m^2*((1-m)/v - 1/m)
b[1,1] <- a[1,1]*(1/m - 1)


################################################
#Determining the shape parameters of Model 2
################################################
#reasoning identical to previous section
simulated <- c(25, 26, 29, 29) #Data from simulations
input <- list(
  y=simulated,
  N=length(simulated),
  n=60
)
PARAM <- c("p")
model2 <- run.jags(model = "priormodel.txt",
                   monitor = PARAM,
                   data = input,
                   burnin = 1000, sample = 10000, thin = 1,
                   n.chains = 1)
model2_sum<-summary(model2)
model2_sum
model2_mcmc <- combine.mcmc(model2)
m <- mean(model2_mcmc)
v <- var(model2_mcmc)
a[2,2] <- m^2*((1-m)/v - 1/m)
b[2,2] <- a[2,2]*(1/m - 1)

################################################
#Determining the shape parameters of Model 3
################################################
a[3,3] <- 1
b[3,3] <- 1

################################################
#Finding the parameters of pseudoprior for Model 1
################################################
#This will run the full model, but set the prior prob for model 1 at 100%
input <- list(
  y=landcount, #outcome
  N=length(landcount),
  mp1=1, #prior prob model 1
  mp2=0,
  mp3=0,
  a=a, #shape parameters
  b=b,
  n=60
)
PARAM <- c("theta","m")
hypo1_model <- run.jags(model = "fullmodel.txt",
                        monitor = PARAM,
                        data = input,
                        burnin = 1000, sample = 10000, thin = 1,
                        n.chains = 1)
hypo1_mcmc <- combine.mcmc(hypo1_model)
m <- mean(hypo1_mcmc[,1])
v <- var(hypo1_mcmc[,1])
#Again we fill in the shape parameters (this time twice for the pseudopriors) 
a[1,2] <- m^2*((1-m)/v - 1/m)
a[1,3] <- a[1,2]
b[1,2] <- a[1,2]*(1/m - 1)
b[1,3] <- b[1,2]

################################################
#Finding the parameters of pseudoprior for hypothesis 2
################################################
#Reasoning is identical to section above
input <- list(
  y=landcount,
  N=length(landcount),
  mp1=0,
  mp2=1,
  mp3=0,  
  a=a,
  b=b,
  n=60
)
PARAM <- c("theta","m")
hypo2_model <- run.jags(model = "fullmodel.txt",
                        monitor = PARAM,
                        #inits=list(theta1=0.5),
                        data = input,
                        burnin = 1000, sample = 10000, thin = 1,
                        n.chains = 1)
hypo2_mcmc <- combine.mcmc(hypo2_model)
m <- mean(hypo2_mcmc[,1])
v <- var(hypo2_mcmc[,1])
a[2,1] <- m^2*((1-m)/v - 1/m)
a[2,3] <- a[2,1]
b[2,1] <- a[2,1]*(1/m - 1)
b[2,3] <- b[2,1]

################################################
#Finding the parameters of pseudoprior for hypothesis 3
################################################
#Reasoning is identical to section above
input <- list(
  y=landcount,
  N=length(landcount),
  mp1=0,
  mp2=0,
  mp3=1,  
  a=a,
  b=b,
  n=60
)
PARAM <- c("theta","m")
hypo1_model <- run.jags(model = "fullmodel.txt",
                        monitor = PARAM,
                        #inits=list(theta1=0.5),
                        data = input,
                        burnin = 1000, sample = 10000, thin = 1,
                        n.chains = 1)
hypo1_mcmc <- combine.mcmc(hypo1_model)
m <- mean(hypo1_mcmc[,1])
v <- var(hypo1_mcmc[,1])
a[3,1] <- m^2*((1-m)/v - 1/m)
a[3,2] <- a[3,1]
b[3,1] <- a[3,1]*(1/m - 1)
b[3,2] <- b[3,1]

################################################
#Visualising the priors
################################################
#If using R Studio, set your plots-window wide enough
#as to make sure the legend fits. Maybe I should have used
#ggplot...
dev.off()
par(mfrow=c(1,2))

#analytically plot the curve generated from a beta
#distribution with the parameters determined in the 
#three previous sections
range = seq(0,1, length=100)
plot(range, dbeta(range, a[1,1], b[1,1]), ylab='density', type ='l', col='green', main = "Beta priors")
lines(range, dbeta(range, a[2,2], b[2,2]), col='red') 
lines(range, dbeta(range, a[3,3], b[3,3]), col='blue')
legend(.5, 24, c('1','2','3'),lty=c(1,1,1),col=c('green', 'red', 'blue'))

#Compare it to the priors we get from sampling from said
#distribution in an MCMC by taking our model and not
#feeding it any data. 
input <- list(
  #y=landcount,
  N=length(landcount),
  mp1=1/3,
  mp2=1/3,
  mp3=1/3,
  a=a,
  b=b,
  n=60
)
PARAM <- c("theta","m")
prior_model <- run.jags(model = "fullmodel.txt",
                        monitor = PARAM,
                        data = input,
                        burnin = 1000, sample = 100000, thin = 10,
                        n.chains = 1)
prior_mcmc <- combine.mcmc(prior_model)
set1 <- prior_mcmc[prior_mcmc[,2]==1,1]
set2 <- prior_mcmc[prior_mcmc[,2]==2,1]
set3 <- prior_mcmc[prior_mcmc[,2]==3,1]

plot(hist(set3, plot=F),main="sampled priors" ,col = "blue",xlim = c(0,1), ylim=c(0,8000))
plot(hist(set2, plot=F), col = "red", add = TRUE,xlim = c(0,1), ylim=c(0,8000))
plot(hist(set1, plot=F), col = "green", add = TRUE,xlim = c(0,1))
legend(.6, 8000, c('1','2','3'),fill=c('green', 'red', 'blue'))

################################################
#Priors vs Pseudopriors
################################################
#Again, make sure your plotting window is wide enough
dev.off()
par(mfrow=c(1,3))

#For all three models, we'll compare the shapes of the 
#prior beta and pseudoprior beta distributions
range = seq(0,1, length=100)
plot(range, dbeta(range, a[1,1], b[1,1]),xlim=c(.2,.6),ylim=c(0,50), ylab='density', type ='l', col='green', main = "Model 1")
lines(range, dbeta(range, a[1,2], b[1,2]), col='red') 

plot(range, dbeta(range, a[2,2], b[2,2]),xlim=c(.2,.6),ylim=c(0,50), ylab='density', type ='l', col='green', main = "Model 2")
lines(range, dbeta(range, a[2,1], b[2,1]), col='red') 
legend(.3, 50, c('real','pseudo'),lty=c(1,1),col=c('green', 'red'))

plot(range, dbeta(range, a[3,3], b[3,3]),xlim=c(.2,.6),ylim=c(0,50), ylab='density', type ='l', col='green', main = "Model 3")
lines(range, dbeta(range, a[3,1], b[3,1]), col='red') 

################################################
#Onto the actual model
################################################
#Same as the times we calculated the pseudoprior
#parameters, but this time with the correct
#prior model probabilities.
input <- list(
  y=landcount,
  N=length(landcount),
  mp1=1/3,
  mp2=1/3,
  mp3=1/3,
  a=a,
  b=b,
  n=60
)
PARAM <- c("theta","m")
#This one takes a bit longer to run due to the 3 chains.
real_model <- run.jags(model = "fullmodel.txt",
                       monitor = PARAM,
                       data = input,
                       burnin = 1000, sample = 100000, thin = 10,
                       n.chains = 3)
summary(real_model)
post_mcmc <- combine.mcmc(real_model)
gelman.diag(real_model)

################################################
#Visualising the posterior
################################################
#Just like we did before, but this time posterior
#Again, large enough plotting window.
dev.off()
set1 <- post_mcmc[post_mcmc[,2]==1,1]
set2 <- post_mcmc[post_mcmc[,2]==2,1]
set3 <- post_mcmc[post_mcmc[,2]==3,1]

plot(hist(set1, plot=F), col = "green", main="posterior samples of binomial probability", xlab="theta")
plot(hist(set3, plot=F), col = "blue", add = TRUE)
plot(hist(set2, plot=F), col = "red", add = TRUE)

legend(.395, 40000, c('model 1','model 2','model 3'),fill=c('green', 'red', 'blue'))

mean(set1)
mean(set2)
mean(set3)

################################################
#Bayes factors
################################################
m <- post_mcmc[,"m"]

mp1<-1/3
mp2<-1/3
mp3<-1/3
#BF 1v2
(mean(m==1)/mean(m==2))/((mp1)/(mp2))
#BF 1v3
(mean(m==1)/mean(m==3))/((mp1)/(mp3))
#BF 2v2
(mean(m==2)/mean(m==3))/((mp2)/(mp3))

################################################
#Slightly more complex model
################################################
#In this one we have to feed all the data (so the 
#1997 data, the modern data, and the simulated data)
input <- list(
  y=landcount,
  modern=modern,
  simulated=simulated,
  N=length(landcount),
  N1=length(modern),
  N2=length(simulated),
  mp1=1/3,
  mp2=1/3,
  mp3=1/3,
  n=60
)
PARAM <- c("theta","m")
real_model2 <- run.jags(model = "combinedmodel.txt",
                        monitor = PARAM,
                        data = input,
                        burnin = 1000, sample = 100000, thin = 10,
                        n.chains = 1)
summary(real_model2)
full_mcmc <- combine.mcmc(real_model2)
m <- full_mcmc[,"m"]

mp1<-1/3
mp2<-1/3
mp3<-1/3
#BF 1v2
(mean(m==1)/mean(m==2))/((mp1)/(mp2))
#BF 1v3
(mean(m==1)/mean(m==3))/((mp1)/(mp3))
#BF 2v3
(mean(m==2)/mean(m==3))/((mp2)/(mp3))

